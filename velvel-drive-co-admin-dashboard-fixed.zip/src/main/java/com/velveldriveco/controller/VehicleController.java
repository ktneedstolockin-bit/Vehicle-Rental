package com.velveldriveco.controller;
import com.velveldriveco.dto.VehicleDtos.VehicleResponse; import com.velveldriveco.service.VehicleService; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api/vehicles")
public class VehicleController { private final VehicleService service; public VehicleController(VehicleService service){this.service=service;} @GetMapping public List<VehicleResponse> all(){return service.all();} @GetMapping("/{id}") public VehicleResponse one(@PathVariable Long id){return service.one(id);} }
