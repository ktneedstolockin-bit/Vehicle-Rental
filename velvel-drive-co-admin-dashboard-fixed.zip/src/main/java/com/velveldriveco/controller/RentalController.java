package com.velveldriveco.controller;
import com.velveldriveco.dto.RentalDtos.*; import com.velveldriveco.service.*; import jakarta.validation.Valid; import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api/rentals")
public class RentalController {
 private final RentalService rentals; private final AuthService auth;
 public RentalController(RentalService rentals,AuthService auth){this.rentals=rentals;this.auth=auth;}
 @PostMapping public RentalResponse book(Authentication a,@Valid @RequestBody BookingRequest req){return rentals.book(auth.byEmail(a.getName()).getId(),req);}
 @GetMapping("/me") public List<RentalResponse> mine(Authentication a){return rentals.customer(auth.byEmail(a.getName()).getId());}
 @PostMapping("/{id}/return") public RentalResponse returnVehicle(Authentication a,@PathVariable Long id){return rentals.returnRental(auth.byEmail(a.getName()).getId(),id);}
}
