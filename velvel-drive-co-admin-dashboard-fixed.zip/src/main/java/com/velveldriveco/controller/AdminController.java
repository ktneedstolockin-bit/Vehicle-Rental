package com.velveldriveco.controller;
import com.velveldriveco.dto.*; import com.velveldriveco.dto.AdminDtos.DashboardResponse; import com.velveldriveco.dto.RentalDtos.RentalResponse; import com.velveldriveco.dto.VehicleDtos.*; import com.velveldriveco.model.Role; import com.velveldriveco.repository.*; import com.velveldriveco.service.*; import jakarta.validation.Valid; import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*; import org.springframework.transaction.annotation.Transactional; import java.util.List;
@RestController @RequestMapping("/api/admin")
public class AdminController {
 private final VehicleService vehicle; private final RentalService rental; private final VehicleRepository vehicles; private final RentalRepository rentals; private final UserRepository users;
 public AdminController(VehicleService vehicle,RentalService rental,VehicleRepository vehicles,RentalRepository rentals,UserRepository users){this.vehicle=vehicle;this.rental=rental;this.vehicles=vehicles;this.rentals=rentals;this.users=users;}
 @Transactional(readOnly = true) @GetMapping("/dashboard") public DashboardResponse dashboard(){return new DashboardResponse(vehicles.count(),vehicles.findByAvailabilityTrueOrderByIdAsc().size(),rentals.countByStatus("ACTIVE"),users.countByRole(Role.CUSTOMER),vehicle.all(),rental.all());}
 @PostMapping("/vehicles") public ResponseEntity<VehicleResponse> create(@Valid @RequestBody VehicleRequest r){return ResponseEntity.ok(vehicle.create(r));}
 @PutMapping("/vehicles/{id}") public VehicleResponse update(@PathVariable Long id,@Valid @RequestBody VehicleRequest r){return vehicle.update(id,r);}
 @DeleteMapping("/vehicles/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){vehicle.delete(id);return ResponseEntity.noContent().build();}
 @PatchMapping("/vehicles/{id}/availability") public VehicleResponse availability(@PathVariable Long id,@RequestParam boolean available){return vehicle.availability(id,available);}
 @GetMapping("/rentals") public List<RentalResponse> rentals(){return rental.all();}
}
