package com.velveldriveco.controller;

import com.velveldriveco.dto.AuthDtos.*;
import com.velveldriveco.model.AccountUser;
import com.velveldriveco.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.*;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth; private final SecurityContextRepository repo;
    public AuthController(AuthService auth,SecurityContextRepository repo){this.auth=auth;this.repo=repo;}

    @PostMapping("/register")
    public ResponseEntity<UserResponse> register(@Valid @RequestBody RegisterRequest request){return ResponseEntity.status(201).body(auth.toResponse(auth.register(request)));}

    @PostMapping("/login")
    public UserResponse login(@Valid @RequestBody LoginRequest request,HttpServletRequest req,HttpServletResponse res){
        AccountUser user=auth.authenticate(request);
        Authentication authentication=new UsernamePasswordAuthenticationToken(user.getEmail(),null,List.of(new SimpleGrantedAuthority("ROLE_"+user.getRole().name())));
        SecurityContext context=SecurityContextHolder.createEmptyContext(); context.setAuthentication(authentication); SecurityContextHolder.setContext(context); repo.saveContext(context,req,res);
        return auth.toResponse(user);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletRequest req){SecurityContextHolder.clearContext();HttpSession s=req.getSession(false);if(s!=null)s.invalidate();return ResponseEntity.noContent().build();}

    @GetMapping("/me")
    public ResponseEntity<?> me(Authentication authentication){
        if(authentication==null || !authentication.isAuthenticated()) return ResponseEntity.status(401).body(Map.of("message","Not logged in."));
        return ResponseEntity.ok(auth.toResponse(auth.byEmail(authentication.getName())));
    }
}
