package com.velveldriveco.controller;
import com.velveldriveco.dto.RentalDtos.RecentRentalResponse; import com.velveldriveco.service.RentalService; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api/rentals")
public class PublicRentalController { private final RentalService service; public PublicRentalController(RentalService service){this.service=service;} @GetMapping("/recent") public List<RecentRentalResponse> recent(){return service.recent();} }
