package com.velveldriveco.dto;
import jakarta.validation.constraints.*;
public final class AuthDtos{ private AuthDtos(){}
 public record LoginRequest(@NotBlank @Email String email,@NotBlank String password){}
 public record RegisterRequest(@NotBlank @Size(max=100) String name,@NotBlank @Email @Size(max=180) String email,@NotBlank @Size(max=30) String phone,@NotBlank @Size(min=6,max=72) String password){}
 public record UserResponse(Long id,String name,String email,String phone,String role){}
}
