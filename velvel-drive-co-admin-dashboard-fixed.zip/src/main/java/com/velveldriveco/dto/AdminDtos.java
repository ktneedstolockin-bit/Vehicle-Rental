package com.velveldriveco.dto;
import com.velveldriveco.dto.RentalDtos.RentalResponse; import com.velveldriveco.dto.VehicleDtos.VehicleResponse; import java.util.List;
public final class AdminDtos{ private AdminDtos(){} public record DashboardResponse(long totalVehicles,long availableVehicles,long activeRentals,long customers,List<VehicleResponse> vehicles,List<RentalResponse> rentals){} }
