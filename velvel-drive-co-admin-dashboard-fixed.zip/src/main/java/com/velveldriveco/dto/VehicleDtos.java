package com.velveldriveco.dto;
import jakarta.validation.constraints.*; import java.util.List;
public final class VehicleDtos{ private VehicleDtos(){}
 public record VehicleRequest(@NotBlank String model,@NotBlank String type,@NotBlank String registration,@NotNull @DecimalMin("1.0") Double price,@NotBlank String imageUrl,String color,List<List<String>> gallery){}
 public record VehicleResponse(Long id,String model,String type,String registration,double price,boolean availability,String color,String image,List<List<String>> gallery){}
}
