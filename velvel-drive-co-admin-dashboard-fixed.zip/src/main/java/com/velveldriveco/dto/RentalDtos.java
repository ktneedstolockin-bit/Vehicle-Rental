package com.velveldriveco.dto;
import jakarta.validation.constraints.*; import java.time.LocalDate;
public final class RentalDtos{ private RentalDtos(){}
 public record BookingRequest(@NotNull @FutureOrPresent LocalDate pickupDate,@NotNull @FutureOrPresent LocalDate returnDate,@NotNull Long vehicleId,@NotBlank String paymentMethod){}
 public record RentalResponse(Long rentalId,String alias,Long customerId,String customerName,Long vehicleId,String vehicleModel,String vehicleType,String vehicleImage,LocalDate pickupDate,LocalDate returnDate,double amount,String paymentMethod,String paymentStatus,String status){}
 public record RecentRentalResponse(Long rentalId,String alias,String vehicleModel,String vehicleType,String vehicleImage,LocalDate pickupDate,LocalDate returnDate,String status){}
}
