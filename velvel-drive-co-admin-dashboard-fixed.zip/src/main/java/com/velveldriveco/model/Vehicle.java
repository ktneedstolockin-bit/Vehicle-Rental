package com.velveldriveco.model;
import jakarta.persistence.*;
@Entity @Table(name="vehicles")
public class Vehicle {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=120) private String model;
 @Column(nullable=false,length=40) private String type;
 @Column(nullable=false,unique=true,length=40) private String registration;
 @Column(nullable=false) private double price;
 @Column(nullable=false) private boolean availability=true;
 @Column(nullable=false,length=80) private String color;
 @Column(nullable=false,length=1000) private String imageUrl;
 @Lob @Column(nullable=false,columnDefinition="LONGTEXT") private String galleryJson;
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getModel(){return model;} public void setModel(String v){model=v;}
 public String getType(){return type;} public void setType(String v){type=v;}
 public String getRegistration(){return registration;} public void setRegistration(String v){registration=v;}
 public double getPrice(){return price;} public void setPrice(double v){price=v;}
 public boolean isAvailability(){return availability;} public void setAvailability(boolean v){availability=v;}
 public String getColor(){return color;} public void setColor(String v){color=v;}
 public String getImageUrl(){return imageUrl;} public void setImageUrl(String v){imageUrl=v;}
 public String getGalleryJson(){return galleryJson;} public void setGalleryJson(String v){galleryJson=v;}
}
