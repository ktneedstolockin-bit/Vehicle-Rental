package com.velveldriveco.model;
import jakarta.persistence.*; import java.time.*;
@Entity @Table(name="payments")
public class Payment {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @OneToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="rental_id",nullable=false,unique=true) private Rental rental;
 @Column(nullable=false) private double amount;
 @Column(nullable=false,length=20) private String method;
 @Column(nullable=false) private LocalDateTime timestamp;
 @Column(nullable=false,length=20) private String status;
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public Rental getRental(){return rental;} public void setRental(Rental v){rental=v;}
 public double getAmount(){return amount;} public void setAmount(double v){amount=v;}
 public String getMethod(){return method;} public void setMethod(String v){method=v;}
 public LocalDateTime getTimestamp(){return timestamp;} public void setTimestamp(LocalDateTime v){timestamp=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
}
