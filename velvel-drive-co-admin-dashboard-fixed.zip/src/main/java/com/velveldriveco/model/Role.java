package com.velveldriveco.model;
public enum Role { CUSTOMER, ADMIN }
