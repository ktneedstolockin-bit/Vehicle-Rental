package com.velveldriveco.model;
import jakarta.persistence.*; import java.time.*;
@Entity @Table(name="rentals",uniqueConstraints=@UniqueConstraint(name="uk_rental_alias",columnNames="alias"))
public class Rental {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=80) private String alias;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="customer_id",nullable=false) private AccountUser customer;
 @ManyToOne(fetch=FetchType.LAZY,optional=false) @JoinColumn(name="vehicle_id",nullable=false) private Vehicle vehicle;
 @Column(nullable=false) private LocalDate pickupDate;
 @Column(nullable=false) private LocalDate returnDate;
 @Column(nullable=false) private double amount;
 @Column(nullable=false,length=20) private String status;
 @Column(nullable=false) private LocalDateTime createdAt;
 public Long getId(){return id;} public void setId(Long v){id=v;}
 public String getAlias(){return alias;} public void setAlias(String v){alias=v;}
 public AccountUser getCustomer(){return customer;} public void setCustomer(AccountUser v){customer=v;}
 public Vehicle getVehicle(){return vehicle;} public void setVehicle(Vehicle v){vehicle=v;}
 public LocalDate getPickupDate(){return pickupDate;} public void setPickupDate(LocalDate v){pickupDate=v;}
 public LocalDate getReturnDate(){return returnDate;} public void setReturnDate(LocalDate v){returnDate=v;}
 public double getAmount(){return amount;} public void setAmount(double v){amount=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
 public LocalDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(LocalDateTime v){createdAt=v;}
}
