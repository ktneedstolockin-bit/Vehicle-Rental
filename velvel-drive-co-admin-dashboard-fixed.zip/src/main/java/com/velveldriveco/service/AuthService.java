package com.velveldriveco.service;

import com.velveldriveco.dto.AuthDtos.LoginRequest;
import com.velveldriveco.dto.AuthDtos.RegisterRequest;
import com.velveldriveco.dto.AuthDtos.UserResponse;
import com.velveldriveco.model.AccountUser;
import com.velveldriveco.model.Role;
import com.velveldriveco.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder){ this.userRepository=userRepository; this.passwordEncoder=passwordEncoder; }

    @Transactional
    public AccountUser register(RegisterRequest request){
        String email=request.email().trim().toLowerCase();
        if(userRepository.existsByEmail(email)) throw new IllegalArgumentException("An account with this email already exists.");
        AccountUser u=new AccountUser(); u.setName(request.name().trim()); u.setEmail(email); u.setPhone(request.phone().trim()); u.setPasswordHash(passwordEncoder.encode(request.password())); u.setRole(Role.CUSTOMER); return userRepository.save(u);
    }
    public AccountUser authenticate(LoginRequest request){
        AccountUser u=userRepository.findByEmail(request.email().trim().toLowerCase()).orElseThrow(()->new IllegalArgumentException("Invalid email or password."));
        if(u.getPasswordHash()==null || u.getRole()==null || !passwordEncoder.matches(request.password(),u.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
        return u;
    }
    public AccountUser byEmail(String email){ return userRepository.findByEmail(email).orElseThrow(()->new IllegalArgumentException("User not found.")); }
    public UserResponse toResponse(AccountUser u){ return new UserResponse(u.getId(),u.getName(),u.getEmail(),u.getPhone(),u.getRole().name()); }
}
