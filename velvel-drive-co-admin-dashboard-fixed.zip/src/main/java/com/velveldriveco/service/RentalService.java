package com.velveldriveco.service;

import com.velveldriveco.dto.RentalDtos.BookingRequest;
import com.velveldriveco.dto.RentalDtos.RecentRentalResponse;
import com.velveldriveco.dto.RentalDtos.RentalResponse;
import com.velveldriveco.model.*;
import com.velveldriveco.repository.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class RentalService {
    private final RentalRepository rentals; private final VehicleRepository vehicles; private final UserRepository users; private final PaymentRepository payments;
    private static final List<String> ADJ=List.of("Velvet","Midnight","Sapphire","Obsidian","Royal","Sterling","Golden","Silver");
    private static final List<String> NOUN=List.of("Voyager","Falcon","Cruiser","Crown","Monarch","Phantom","Rider","Apex");
    public RentalService(RentalRepository rentals,VehicleRepository vehicles,UserRepository users,PaymentRepository payments){this.rentals=rentals;this.vehicles=vehicles;this.users=users;this.payments=payments;}

    @Transactional
    public RentalResponse book(Long customerId,BookingRequest req){
        AccountUser customer=users.findById(customerId).orElseThrow(()->new NoSuchElementException("Customer not found."));
        Vehicle vehicle=vehicles.findById(req.vehicleId()).orElseThrow(()->new NoSuchElementException("Vehicle not found."));
        if(!vehicle.isAvailability()) throw new IllegalArgumentException("This vehicle is currently unavailable.");
        LocalDate pickup=req.pickupDate(), ret=req.returnDate();
        if(ret==null||pickup==null||!ret.isAfter(pickup)) throw new IllegalArgumentException("Return date must be after pickup date.");
        long days=ChronoUnit.DAYS.between(pickup,ret); double amount=days*vehicle.getPrice();
        Rental r=new Rental(); r.setAlias(generateAlias()); r.setCustomer(customer); r.setVehicle(vehicle); r.setPickupDate(pickup); r.setReturnDate(ret); r.setAmount(amount); r.setStatus("ACTIVE"); r.setCreatedAt(LocalDateTime.now()); rentals.save(r);
        Payment p=new Payment(); p.setRental(r); p.setAmount(amount); p.setMethod(req.paymentMethod().trim().toUpperCase()); p.setTimestamp(LocalDateTime.now()); p.setStatus("SUCCESS"); payments.save(p);
        vehicle.setAvailability(false); vehicles.save(vehicle);
        return toResponse(r,p);
    }
    @Transactional(readOnly = true)
    public List<RentalResponse> customer(Long customerId){return rentals.findByCustomerIdOrderByCreatedAtDesc(customerId).stream().map(this::mapWithPayment).toList();}
    @Transactional(readOnly = true)
    public List<RecentRentalResponse> recent(){return rentals.findTop6ByOrderByCreatedAtDesc().stream().map(r->new RecentRentalResponse(r.getId(),r.getAlias(),r.getVehicle().getModel(),r.getVehicle().getType(),r.getVehicle().getImageUrl(),r.getPickupDate(),r.getReturnDate(),r.getStatus())).toList();}
    @Transactional(readOnly = true)
    public List<RentalResponse> all(){return rentals.findAllByOrderByCreatedAtDesc().stream().map(this::mapWithPayment).toList();}
    @Transactional public RentalResponse returnRental(Long customerId,Long id){
        Rental r=rentals.findById(id).orElseThrow(()->new NoSuchElementException("Rental not found."));
        if(!Objects.equals(r.getCustomer().getId(),customerId)) throw new AccessDeniedException("You cannot modify this rental.");
        if(!"ACTIVE".equals(r.getStatus())) throw new IllegalArgumentException("This rental has already been returned.");
        r.setStatus("COMPLETED"); r.getVehicle().setAvailability(true); vehicles.save(r.getVehicle()); rentals.save(r); return mapWithPayment(r);
    }
    private RentalResponse mapWithPayment(Rental r){return toResponse(r,payments.findByRentalId(r.getId()).orElse(null));}
    private RentalResponse toResponse(Rental r,Payment p){return new RentalResponse(r.getId(),r.getAlias(),r.getCustomer().getId(),r.getCustomer().getName(),r.getVehicle().getId(),r.getVehicle().getModel(),r.getVehicle().getType(),r.getVehicle().getImageUrl(),r.getPickupDate(),r.getReturnDate(),r.getAmount(),p==null?null:p.getMethod(),p==null?null:p.getStatus(),r.getStatus());}
    private String generateAlias(){for(int i=0;i<100;i++){String a=ADJ.get((int)(Math.random()*ADJ.size()))+" "+NOUN.get((int)(Math.random()*NOUN.size()))+" "+(100+(int)(Math.random()*900)); if(!rentals.existsByAlias(a))return a;}return "Velvet Drive "+(System.currentTimeMillis()%100000);}
}
