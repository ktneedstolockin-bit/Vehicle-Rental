package com.velveldriveco.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.velveldriveco.dto.VehicleDtos.VehicleRequest;
import com.velveldriveco.dto.VehicleDtos.VehicleResponse;
import com.velveldriveco.model.Vehicle;
import com.velveldriveco.repository.VehicleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class VehicleService {
    private final VehicleRepository repo; private final ObjectMapper mapper;
    public VehicleService(VehicleRepository repo,ObjectMapper mapper){this.repo=repo;this.mapper=mapper;}
    public List<VehicleResponse> all(){return repo.findAllByOrderByIdAsc().stream().map(this::toResponse).toList();}
    public VehicleResponse one(Long id){return toResponse(repo.findById(id).orElseThrow(()->new NoSuchElementException("Vehicle not found.")));}
    @Transactional public VehicleResponse create(VehicleRequest r){
        if(repo.existsByRegistrationIgnoreCase(r.registration())) throw new IllegalArgumentException("A vehicle with this registration already exists.");
        Vehicle v=new Vehicle(); apply(v,r); v.setAvailability(true); return toResponse(repo.save(v));
    }
    @Transactional public VehicleResponse update(Long id,VehicleRequest r){
        Vehicle v=repo.findById(id).orElseThrow(()->new NoSuchElementException("Vehicle not found."));
        repo.findByRegistrationIgnoreCase(r.registration()).ifPresent(other->{if(!other.getId().equals(id)) throw new IllegalArgumentException("A vehicle with this registration already exists.");});
        apply(v,r); return toResponse(repo.save(v));
    }
    @Transactional public void delete(Long id){if(!repo.existsById(id)) throw new NoSuchElementException("Vehicle not found."); repo.deleteById(id);}
    @Transactional public VehicleResponse availability(Long id,boolean value){Vehicle v=repo.findById(id).orElseThrow(()->new NoSuchElementException("Vehicle not found."));v.setAvailability(value);return toResponse(repo.save(v));}
    private void apply(Vehicle v,VehicleRequest r){
        v.setModel(r.model().trim()); v.setType(r.type().trim()); v.setRegistration(r.registration().trim().toUpperCase()); v.setPrice(r.price()); v.setImageUrl(r.imageUrl().trim()); v.setColor(r.color()==null||r.color().isBlank()?"Premium finish":r.color().trim());
        try{v.setGalleryJson(mapper.writeValueAsString(r.gallery()==null||r.gallery().isEmpty()?List.of(List.of(r.imageUrl(),"Exterior")):r.gallery()));}catch(Exception e){throw new IllegalArgumentException("Invalid vehicle gallery.");}
    }
    public VehicleResponse toResponse(Vehicle v){
        try{return new VehicleResponse(v.getId(),v.getModel(),v.getType(),v.getRegistration(),v.getPrice(),v.isAvailability(),v.getColor(),v.getImageUrl(),mapper.readValue(v.getGalleryJson(),new TypeReference<List<List<String>>>(){}));}
        catch(Exception e){return new VehicleResponse(v.getId(),v.getModel(),v.getType(),v.getRegistration(),v.getPrice(),v.isAvailability(),v.getColor(),v.getImageUrl(),List.of(List.of(v.getImageUrl(),"Exterior")));}
    }
}
