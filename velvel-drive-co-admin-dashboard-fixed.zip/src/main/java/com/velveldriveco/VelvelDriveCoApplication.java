package com.velveldriveco;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class VelvelDriveCoApplication { public static void main(String[] args){ SpringApplication.run(VelvelDriveCoApplication.class,args); } }
