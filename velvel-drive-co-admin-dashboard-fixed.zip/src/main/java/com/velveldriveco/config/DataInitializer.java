package com.velveldriveco.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.velveldriveco.model.AccountUser;
import com.velveldriveco.model.Role;
import com.velveldriveco.model.Vehicle;
import com.velveldriveco.repository.UserRepository;
import com.velveldriveco.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.List;

@Configuration
public class DataInitializer {
    @Bean CommandLineRunner init(UserRepository users,VehicleRepository vehicles,PasswordEncoder encoder,ObjectMapper mapper,
                                 @Value("${app.admin.email}") String adminEmail,@Value("${app.admin.password}") String adminPassword){
        return args -> {
            String normalizedAdminEmail = adminEmail.trim().toLowerCase();
            AccountUser admin = users.findByEmail(normalizedAdminEmail).orElseGet(AccountUser::new);
            // Always repair/synchronize the demo admin record at startup. This fixes stale
            // credentials/roles left by older project versions without affecting customers.
            admin.setName("Velvel Drive Co. Admin");
            admin.setEmail(normalizedAdminEmail);
            admin.setPhone("9999999999");
            admin.setPasswordHash(encoder.encode(adminPassword));
            admin.setRole(Role.ADMIN);
            users.save(admin);
            if(vehicles.count()==0){
                seed(vehicles,mapper,"BMW 3 Series","Car","DL01AB1234",3500,true,"Tanzanite Blue","https://cdn-s3.autocarindia.com/BMW/3-Series/_AAB6810.JPG?fm=auto&q=75&w=728",List.of(
                    List.of("https://cdn-s3.autocarindia.com/BMW/3-Series/_AAB6810.JPG?fm=auto&q=75&w=728","Exterior — Front 3/4"),List.of("https://cdn-s3.autocarindia.com/BMW/3-Series/_AAB6861.JPG?fm=auto&q=75&w=728","Exterior — Front Left"),List.of("https://cdn-s3.autocarindia.com/BMW/3-Series/_AAB6953.JPG?fm=auto&q=75&w=728","Exterior — Front Right"),List.of("https://cdn-s3.autocarindia.com/BMW/3-Series/_AAB6914.JPG?fm=auto&q=75&w=728","Exterior — Rear"),List.of("https://cdn-s3.autocarindia.com/BMW/3-Series/_AAB6776.JPG?fm=auto&q=75&w=728","Interior — Dashboard")));
                seed(vehicles,mapper,"BMW X5","SUV","DL02CD5678",4500,true,"Black Sapphire Metallic","https://cdn-s3.autocarindia.com/legacy/cdni/mmv_images/colors/20250520023500_BMW_X5_Black_Sapphire_Metallic%5B1%5D.png?fm=auto&q=75&w=640",List.of(
                    List.of("https://cdn-s3.autocarindia.com/legacy/cdni/mmv_images/colors/20250520023500_BMW_X5_Black_Sapphire_Metallic%5B1%5D.png?fm=auto&q=75&w=640","Exterior — Black Sapphire"),List.of("https://cdn-s3.autocarindia.com/BMW/X5/_AAB6024.JPG?fm=auto&q=75&w=640","Exterior — Front Left"),List.of("https://cdn-s3.autocarindia.com/BMW/X5/_AAB5884.JPG?fm=auto&q=75&w=640","Exterior — Rear 3/4"),List.of("https://cdn-s3.autocarindia.com/BMW/X5/_AAB6016.JPG?fm=auto&q=75&w=640","Exterior — Rear"),List.of("https://cdn-s3.autocarindia.com/BMW/X5/_AAB6073.JPG?fm=auto&q=75&w=640","Interior — Dashboard")));
                seed(vehicles,mapper,"Royal Enfield Classic","Bike","DL03EF9012",1500,true,"Black","https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_DSF3017.JPG?fm=auto&q=75&w=728",List.of(
                    List.of("https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_DSF3017.JPG?fm=auto&q=75&w=728","Exterior — Front 3/4"),List.of("https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_DSF2350.JPG?fm=auto&q=75&w=728","Exterior — Side Profile"),List.of("https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_DSF3244.JPG?fm=auto&q=75&w=728","Exterior — Rear 3/4"),List.of("https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_BE00017.JPG?fm=auto&q=75&w=728","Exterior — Tail Detail"),List.of("https://cdn-s3.autocarindia.com/RoyalEnfield/Classic-350/_DSF2564.JPG?fm=auto&q=75&w=728","Cockpit — Instrument Cluster")));
                seed(vehicles,mapper,"Lamborghini Urus","Luxury","DL04GH3456",12000,true,"Nero Noctis","https://cdn-s3.autocarindia.com/Lamborghini/Urus/ABI_9703.jpg?q=75&w=728",List.of(
                    List.of("https://cdn-s3.autocarindia.com/Lamborghini/Urus/ABI_9703.jpg?q=75&w=728","Exterior — Front Left 3/4"),List.of("https://cdn-s3.autocarindia.com/Lamborghini/Urus/ABI_9954.jpg?q=75&w=728","Exterior — Front Right 3/4"),List.of("https://cdn-s3.autocarindia.com/Lamborghini/Urus/ABI_0635.jpg?q=75&w=728","Exterior — Rear"),List.of("https://cdn-s3.autocarindia.com/Lamborghini/Urus/DSC00362.jpg?q=75&w=728","Interior — Dashboard")));
                seed(vehicles,mapper,"Yamaha R1","Bike","DL05IJ7890",2800,true,"Gallery-matched finish","https://media.zigcdn.com/media/model/2024/Sep/front-right-view-1121516099_930x620.jpg",List.of(
                    List.of("https://media.zigcdn.com/media/model/2024/Sep/front-right-view-1121516099_930x620.jpg","Exterior — Front Right"),List.of("https://media.zigcdn.com/media/model/2024/Sep/right-side-view-30074283_930x620.jpg","Exterior — Right Side"),List.of("https://media.zigcdn.com/media/model/2024/Sep/front-view-1989165112_930x620.jpg","Exterior — Front"),List.of("https://media.zigcdn.com/media/model/2024/Sep/rear-view-1430695304_930x620.jpg","Exterior — Rear"),List.of("https://media.zigcdn.com/media/model/2024/Sep/speedometer-541776003_930x620.jpg","Cockpit — Speedometer")));
                seed(vehicles,mapper,"Continental GT 650","Bike","DL06KL1234",2200,false,"Black","https://images.unsplash.com/photo-1656420731892-a4ece094df5a?auto=format&fit=crop&w=1600&q=85",List.of(
                    List.of("https://images.unsplash.com/photo-1656420731892-a4ece094df5a?auto=format&fit=crop&w=1800&q=90","Exterior — Front 3/4"),List.of("https://images.unsplash.com/photo-1656420731611-ffae337fab6a?auto=format&fit=crop&w=1800&q=90","Exterior — Side Profile"),List.of("https://images.unsplash.com/photo-1706673250672-6c7ffdaaaaf3?auto=format&fit=crop&w=1800&q=90","Exterior — Rear / Profile"),List.of("https://images.unsplash.com/photo-1613972461450-cf60cab4dce6?auto=format&fit=crop&w=1800&q=90","Detail — Wheel / Body")));
            }
        };
    }
    private void seed(VehicleRepository repo,ObjectMapper mapper,String model,String type,String reg,double price,boolean available,String color,String image,List<List<String>> gallery){try{Vehicle v=new Vehicle();v.setModel(model);v.setType(type);v.setRegistration(reg);v.setPrice(price);v.setAvailability(available);v.setColor(color);v.setImageUrl(image);v.setGalleryJson(mapper.writeValueAsString(gallery));repo.save(v);}catch(Exception e){throw new IllegalStateException("Failed to seed vehicle data",e);}}
}
