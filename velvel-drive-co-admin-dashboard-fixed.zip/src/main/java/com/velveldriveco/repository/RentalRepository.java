package com.velveldriveco.repository;
import com.velveldriveco.model.Rental; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface RentalRepository extends JpaRepository<Rental,Long>{ List<Rental> findByCustomerIdOrderByCreatedAtDesc(Long id); List<Rental> findTop6ByOrderByCreatedAtDesc(); List<Rental> findAllByOrderByCreatedAtDesc(); long countByStatus(String status); boolean existsByAlias(String alias); }
