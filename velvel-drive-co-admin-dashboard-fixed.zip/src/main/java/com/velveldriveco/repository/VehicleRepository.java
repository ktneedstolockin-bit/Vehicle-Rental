package com.velveldriveco.repository;
import com.velveldriveco.model.Vehicle; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface VehicleRepository extends JpaRepository<Vehicle,Long>{ List<Vehicle> findAllByOrderByIdAsc(); List<Vehicle> findByAvailabilityTrueOrderByIdAsc(); boolean existsByRegistrationIgnoreCase(String registration); Optional<Vehicle> findByRegistrationIgnoreCase(String registration); }
