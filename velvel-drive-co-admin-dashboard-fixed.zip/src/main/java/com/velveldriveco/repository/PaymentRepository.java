package com.velveldriveco.repository;
import com.velveldriveco.model.Payment; import org.springframework.data.jpa.repository.JpaRepository; import java.util.Optional;
public interface PaymentRepository extends JpaRepository<Payment,Long>{ Optional<Payment> findByRentalId(Long rentalId); }
