package com.velveldriveco.repository;
import com.velveldriveco.model.AccountUser; import com.velveldriveco.model.Role; import org.springframework.data.jpa.repository.JpaRepository; import java.util.*;
public interface UserRepository extends JpaRepository<AccountUser,Long>{ Optional<AccountUser> findByEmail(String email); boolean existsByEmail(String email); long countByRole(Role role); }
