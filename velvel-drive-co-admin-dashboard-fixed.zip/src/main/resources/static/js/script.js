const API_BASE_URL = (() => {
  // If the frontend is opened with Live Server/file://, call the Spring Boot backend on 8080.
  // If Spring Boot itself serves the frontend, keep the API same-origin.
  const host = window.location.hostname;
  const port = window.location.port;
  if (window.location.protocol === "file:" || ((host === "localhost" || host === "127.0.0.1") && port && port !== "8080")) {
    return "http://localhost:8080/api";
  }
  return "/api";
})();
let currentUser = null;
let currentBookingVehicle = null;
let currentVehicleGallery = [];

async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  if (options.body && !headers["Content-Type"]) headers["Content-Type"] = "application/json";

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers, credentials: "include" });
  } catch (_) {
    throw new Error(`Cannot connect to the backend at ${API_BASE_URL}. Start Spring Boot first.`);
  }

  if (response.status === 204) return null;
  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json") ? await response.json() : await response.text();

  if (!response.ok) {
    let message = typeof data === "object" && data?.message
      ? data.message
      : (typeof data === "string" && data.trim() ? data.trim() : "Request failed.");

    if (response.status === 400) message = message || "Please check the entered details.";
    if (response.status === 401) message = "Invalid email or password.";
    if (response.status === 403) message = "You do not have permission for this action.";
    if (response.status === 404) message = message || "The requested item was not found.";
    if (response.status === 409) message = message || "That record already exists.";
    if (response.status >= 500) message = "The server could not process the request. Check the Spring Boot terminal for the exact error.";

    const error = new Error(message);
    error.status = response.status;
    throw error;
  }
  return data;
}

async function loadCurrentUser() {
  try { currentUser = await api("/auth/me"); }
  catch (_) { currentUser = null; }
  return currentUser;
}
function getCurrentUser(){ return currentUser; }
function isAdmin(){ return currentUser?.role === "ADMIN"; }
async function logoutUser(){ try{await api("/auth/logout",{method:"POST"});}catch(_){} currentUser=null; location.href="login.html"; }
function toggleMenu(){document.getElementById("mainNav")?.classList.toggle("open");}

async function setupNavigation(){
  const nav=document.getElementById("mainNav"); if(!nav) return;
  await loadCurrentUser();
  const adminLink=nav.querySelector(".admin-link"), rentalsLink=nav.querySelector('a[href="my-rentals.html"]'), authLink=nav.querySelector(".nav-login");
  if(adminLink) adminLink.style.display=isAdmin()?"inline-flex":"none";
  if(rentalsLink) rentalsLink.style.display=currentUser?.role==="CUSTOMER"?"inline-flex":"none";
  if(authLink){
    if(currentUser){authLink.textContent="Logout";authLink.href="#";authLink.onclick=e=>{e.preventDefault();logoutUser();};}
    else{authLink.textContent="Login";authLink.href="login.html";authLink.onclick=null;}
  }
}
document.addEventListener("DOMContentLoaded",setupNavigation);

function getVehicleImage(v){return v?.gallery?.[0]?.[0]||v?.image||"";}
function vehicleCard(v){
  const status=v.availability?'<span class="badge available">Available</span>':'<span class="badge unavailable">Rented</span>';
  const image=getVehicleImage(v);
  return `<article class="vehicle-card"><div class="vehicle-visual photo-wrap"><img src="${escapeHtml(image)}" alt="${escapeHtml(v.model)}" loading="lazy"><span class="photo-shade"></span><span class="vehicle-type-pill">${escapeHtml(v.type)}</span></div><div class="vehicle-card-body"><div class="vehicle-top"><div><h3>${escapeHtml(v.model)}</h3><p class="vehicle-subtitle">${escapeHtml(v.registration)}</p></div>${status}</div><div class="vehicle-meta"><span>${escapeHtml(v.color||"Premium finish")}</span><span>Inspected</span></div><div class="price">₹${Number(v.price).toLocaleString("en-IN")} <small>/ day</small></div><a class="btn ${v.availability?"primary":"secondary"} full" href="${v.availability?`vehicle-details.html?id=${v.id}`:"#"}">${v.availability?"View Details":"Currently Unavailable"}</a></div></article>`;
}

async function renderFeaturedVehicles(){
  const el=document.getElementById("featuredVehicles"); if(!el)return;
  try{const vehicles=await api("/vehicles");el.innerHTML=vehicles.filter(v=>v.availability).slice(0,3).map(vehicleCard).join("");}
  catch(_){el.innerHTML='<div class="empty">Unable to load vehicles right now.</div>';}
}

async function renderRecentlyRented(){
  const el=document.getElementById("recentlyRentedList"); if(!el)return;
  try{
    const rentals=await api("/rentals/recent");
    if(!rentals.length){el.innerHTML='<div class="empty recent-empty"><span class="eyebrow">NO RECENT BOOKINGS</span><h3>Your latest rental will appear here.</h3><p>Reserve a vehicle and it will be added automatically with a generated alias.</p></div>';return;}
    el.innerHTML=rentals.map(r=>`<article class="recent-rental-card"><div class="recent-rental-image"><img src="${escapeHtml(r.vehicleImage)}" alt="${escapeHtml(r.vehicleModel)}" loading="lazy"><span class="recent-rental-type">${escapeHtml(r.vehicleType)}</span></div><div class="recent-rental-body"><span class="recent-alias-label">RENTED AS</span><h3>${escapeHtml(r.alias)}</h3><p>${escapeHtml(r.vehicleModel)}</p><div class="recent-rental-meta"><span>${escapeHtml(r.pickupDate)}</span><span>→</span><span>${escapeHtml(r.returnDate)}</span></div><span class="badge ${r.status==="ACTIVE"?"available":"unavailable"}">${escapeHtml(r.status)}</span></div></article>`).join("");
  }catch(_){el.innerHTML='<div class="empty">Unable to load recent rentals.</div>';}
}

async function initVehiclesPage(){
  const search=document.getElementById("searchInput"),type=document.getElementById("typeFilter"),sort=document.getElementById("sortFilter"); if(!search||!type||!sort)return;
  const requestedType=new URLSearchParams(location.search).get("type"); if(requestedType)type.value=requestedType;
  let allVehicles=[];
  try{allVehicles=await api("/vehicles");}catch(_){document.getElementById("vehiclesGrid").innerHTML='<div class="empty">Unable to load vehicles from the backend.</div>';return;}
  function render(){let data=[...allVehicles];const q=search.value.trim().toLowerCase();if(q)data=data.filter(v=>`${v.model} ${v.registration} ${v.type}`.toLowerCase().includes(q));if(type.value!=="All")data=data.filter(v=>v.type===type.value);if(sort.value==="low")data.sort((a,b)=>a.price-b.price);if(sort.value==="high")data.sort((a,b)=>b.price-a.price);document.getElementById("vehiclesGrid").innerHTML=data.length?data.map(vehicleCard).join(""): '<div class="empty"><h3>No vehicles found</h3><p>Try another search or category.</p></div>';}
  [search,type,sort].forEach(x=>{x.addEventListener("input",render);x.addEventListener("change",render);});render();
}

async function renderVehicleDetails(){
  const target=document.getElementById("vehicleDetails");if(!target)return;
  const id=new URLSearchParams(location.search).get("id");
  try{
    const v=await api(`/vehicles/${id}`);const fallback=v.image;const gallery=Array.isArray(v.gallery)&&v.gallery.length?v.gallery:[[fallback,"Vehicle View"]];
    target.innerHTML=`<div class="details-layout"><div class="vehicle-gallery"><div class="details-visual photo-wrap large-photo" id="galleryMain"><img id="galleryMainImage" class="gallery-main-image" src="${escapeHtml(gallery[0][0])}" alt="${escapeHtml(v.model)} — ${escapeHtml(gallery[0][1])}"><span class="photo-shade"></span><span class="vehicle-type-pill">${escapeHtml(v.type)}</span><span class="gallery-main-label" id="galleryMainLabel">${escapeHtml(gallery[0][1])}</span></div><div class="gallery-thumbs" id="galleryThumbs">${gallery.map((item,index)=>`<button class="gallery-thumb ${index===0?"active":""}" type="button" onclick="selectGalleryImage(${index})"><img src="${escapeHtml(item[0])}" alt="${escapeHtml(item[1])}" loading="lazy"><span>${escapeHtml(item[1])}</span></button>`).join("")}</div><div class="gallery-note"><span>PHOTO GALLERY</span><strong>Explore every angle</strong><small>Exterior views, close-up details and interior/cockpit views.</small></div></div><section class="detail-card"><span class="eyebrow">SIGNATURE DRIVE</span><h1>${escapeHtml(v.model)}</h1><p class="helper">${v.availability?"Available now for your next journey.":"This vehicle is currently rented."}</p><div class="detail-list"><div class="detail-item"><span>Registration</span><strong>${escapeHtml(v.registration)}</strong></div><div class="detail-item"><span>Vehicle ID</span><strong>${escapeHtml(v.id)}</strong></div><div class="detail-item"><span>Daily Price</span><strong>₹${Number(v.price).toLocaleString("en-IN")}</strong></div><div class="detail-item"><span>Status</span><strong>${v.availability?"Available":"Unavailable"}</strong></div><div class="detail-item"><span>Colour</span><strong>${escapeHtml(v.color||"Premium finish")}</strong></div></div>${v.availability?`<a class="btn primary full" href="booking.html?id=${v.id}">Reserve This Vehicle</a>`:`<button class="btn secondary full" disabled>Currently Unavailable</button>`}</section></div>`;
    currentVehicleGallery=gallery;
  }catch(error){target.innerHTML=`<div class="empty">${escapeHtml(error.message)} <a class="text-link" href="vehicles.html">Browse vehicles</a></div>`;}
}
function selectGalleryImage(index){const item=currentVehicleGallery[index];if(!item)return;const image=document.getElementById("galleryMainImage"),label=document.getElementById("galleryMainLabel");if(image){image.style.opacity="0.25";setTimeout(()=>{image.src=item[0];image.alt=item[1]||"Vehicle view";image.style.opacity="1";},90);}if(label)label.textContent=item[1]||"Vehicle View";document.querySelectorAll(".gallery-thumb").forEach((btn,i)=>btn.classList.toggle("active",i===index));}

async function registerUser(e){e.preventDefault();try{await api("/auth/register",{method:"POST",body:JSON.stringify({name:document.getElementById("regName").value.trim(),email:document.getElementById("regEmail").value.trim(),phone:document.getElementById("regPhone").value.trim(),password:document.getElementById("regPassword").value})});showMessage("registerMessage","Account created. Please login to continue.");setTimeout(()=>location.href="login.html",700);}catch(error){showMessage("registerMessage",error.message,true);}}
function fillDemoAdmin(){document.getElementById("loginEmail").value="admin@driveeasy.com";document.getElementById("loginPassword").value="Admin@123";}
async function loginUser(e){e.preventDefault();try{const user=await api("/auth/login",{method:"POST",body:JSON.stringify({email:document.getElementById("loginEmail").value.trim(),password:document.getElementById("loginPassword").value})});currentUser=user;showMessage("loginMessage",user.role==="ADMIN"?"Admin login successful.":"Login successful.");setTimeout(()=>location.href=user.role==="ADMIN"?"admin.html":"my-rentals.html",500);}catch(error){showMessage("loginMessage",error.message,true);}}

async function initBookingPage(){
  const area=document.getElementById("bookingArea");if(!area)return;const id=new URLSearchParams(location.search).get("id");
  try{const v=await api(`/vehicles/${id}`);if(!v.availability){area.innerHTML='<div class="empty">This vehicle is not available right now.</div>';return;}const today=new Date().toISOString().split("T")[0];area.innerHTML=`<div class="booking-layout"><form class="booking-card" onsubmit="confirmBooking(event)"><span class="eyebrow">YOUR RESERVATION</span><h2>Rental details</h2><input type="hidden" id="bookingVehicleId" value="${v.id}"><label>Pickup Date</label><input id="pickupDate" class="input" type="date" min="${today}" required><label>Return Date</label><input id="returnDate" class="input" type="date" min="${today}" required><label>Payment Method</label><select id="paymentMethod" class="input"><option>UPI</option><option>Card</option><option>Cash</option></select><button class="btn primary full" type="submit">Confirm & Pay</button><p id="bookingMessage" class="form-message"></p></form><aside class="summary-card booking-preview"><div class="mini-vehicle"><img src="${escapeHtml(v.image)}" alt="${escapeHtml(v.model)}"></div><h2>${escapeHtml(v.model)}</h2><div class="summary-line"><span>Daily rate</span><strong>₹${Number(v.price).toLocaleString("en-IN")}</strong></div><div class="summary-line"><span>Pickup</span><strong id="summaryPickup">—</strong></div><div class="summary-line"><span>Return</span><strong id="summaryReturn">—</strong></div><div class="summary-total">Total: <span id="summaryTotal">₹0</span></div></aside></div>`;["pickupDate","returnDate"].forEach(id2=>document.getElementById(id2).addEventListener("change",updateBookingSummary));currentBookingVehicle=v;}catch(error){area.innerHTML=`<div class="empty">${escapeHtml(error.message)}</div>`;}
}
function updateBookingSummary(){const p=document.getElementById("pickupDate")?.value,r=document.getElementById("returnDate")?.value,v=currentBookingVehicle;if(!v)return;document.getElementById("summaryPickup").textContent=p||"—";document.getElementById("summaryReturn").textContent=r||"—";if(p&&r){const days=Math.ceil((new Date(r)-new Date(p))/86400000);document.getElementById("summaryTotal").textContent=days>0?`₹${(days*v.price).toLocaleString("en-IN")} (${days} day${days===1?'':'s'})`:"Invalid dates";}else document.getElementById("summaryTotal").textContent="₹0";}
async function confirmBooking(e){e.preventDefault();try{await loadCurrentUser();if(!currentUser||currentUser.role!=="CUSTOMER"){showMessage("bookingMessage","Please login with a customer account before booking.",true);setTimeout(()=>location.href="login.html",800);return;}const rental=await api("/rentals",{method:"POST",body:JSON.stringify({vehicleId:Number(document.getElementById("bookingVehicleId").value),pickupDate:document.getElementById("pickupDate").value,returnDate:document.getElementById("returnDate").value,paymentMethod:document.getElementById("paymentMethod").value})});document.getElementById("bookingArea").innerHTML=`<div class="success-box"><span class="eyebrow">CONFIRMED</span><h2>✓ Booking confirmed</h2><p>Your rental has been saved to MySQL.</p><p><strong>Booking ID:</strong> REN${rental.rentalId}</p><p><strong>Rental Alias:</strong> ${escapeHtml(rental.alias)}</p><p><strong>Payment:</strong> ${escapeHtml(rental.paymentMethod)} • ${escapeHtml(rental.paymentStatus)}</p><p><strong>Amount:</strong> ₹${Number(rental.amount).toLocaleString("en-IN")}</p><div style="margin-top:18px;display:flex;gap:10px;flex-wrap:wrap"><a class="btn primary" href="my-rentals.html">View My Rentals</a><a class="btn secondary" href="vehicles.html">Browse More Vehicles</a></div></div>`;}catch(error){showMessage("bookingMessage",error.message,true);}}

async function renderMyRentals(){const list=document.getElementById("rentalsList");if(!list)return;await loadCurrentUser();if(!currentUser||currentUser.role!=="CUSTOMER"){list.innerHTML='<div class="empty"><h3>Please login as a customer.</h3><p><a href="login.html" class="text-link">Go to Login</a></p></div>';return;}try{const rentals=await api("/rentals/me");document.getElementById("activeCount").textContent=rentals.filter(r=>r.status==="ACTIVE").length;document.getElementById("completedCount").textContent=rentals.filter(r=>r.status==="COMPLETED").length;document.getElementById("totalCount").textContent=rentals.length;if(!rentals.length){list.innerHTML='<div class="empty"><h3>No rentals yet.</h3><p>Browse vehicles and make your first booking.</p><a class="btn primary" style="margin-top:14px" href="vehicles.html">Browse Vehicles</a></div>';return;}list.innerHTML=rentals.map(r=>`<article class="rental-card"><div class="rental-header"><div><span class="eyebrow">REN${r.rentalId}</span><h3>${escapeHtml(r.vehicleModel)}</h3><div class="rental-alias-line"><span>Rented as</span><strong>${escapeHtml(r.alias)}</strong></div></div><span class="badge ${r.status==="ACTIVE"?"available":"unavailable"}">${escapeHtml(r.status)}</span></div><div class="rental-card-main"><img class="rental-card-image" src="${escapeHtml(r.vehicleImage)}" alt="${escapeHtml(r.vehicleModel)}"><div class="rental-grid"><div class="rental-item"><span>Pickup</span><strong>${escapeHtml(r.pickupDate)}</strong></div><div class="rental-item"><span>Return</span><strong>${escapeHtml(r.returnDate)}</strong></div><div class="rental-item"><span>Amount</span><strong>₹${Number(r.amount).toLocaleString("en-IN")}</strong></div><div class="rental-item"><span>Payment</span><strong>${escapeHtml(r.paymentStatus||"—")}</strong></div></div></div><div class="rental-actions">${r.status==="ACTIVE"?`<button class="btn primary" onclick="returnVehicle(${r.rentalId})">Return Vehicle</button>`:""}<button class="btn secondary" onclick="alert('Rental Alias: ${r.alias}\\nVehicle: ${r.vehicleModel}\\nStatus: ${r.status}')">View Details</button></div></article>`).join("");}catch(error){list.innerHTML=`<div class="empty">${escapeHtml(error.message)}</div>`;}}
async function returnVehicle(rentalId){try{await api(`/rentals/${rentalId}/return`,{method:"POST"});await renderMyRentals();}catch(error){alert(error.message);}}

async function guardAdminPage(){if(!document.body.dataset.adminPage)return true;await loadCurrentUser();if(!isAdmin()){document.body.innerHTML='<main class="auth-wrapper"><section class="auth-card"><span class="eyebrow">ACCESS RESTRICTED</span><h1>Admin access only</h1><p class="helper">You must log in with an administrator account to manage vehicles and rentals.</p><a class="btn primary full" href="login.html">Go to Login</a></section></main>';return false;}return true;}
async function renderAdmin(){if(!(await guardAdminPage()))return;try{const d=await api("/admin/dashboard");document.getElementById("statVehicles").textContent=d.totalVehicles;document.getElementById("statAvailable").textContent=d.availableVehicles;document.getElementById("statActive").textContent=d.activeRentals;document.getElementById("statCustomers").textContent=d.customers;document.getElementById("adminVehiclesTable").innerHTML=d.vehicles.map(v=>`<tr><td>${escapeHtml(v.model)}</td><td>${escapeHtml(v.type)}</td><td>${escapeHtml(v.registration)}</td><td>₹${Number(v.price).toLocaleString("en-IN")}</td><td>${v.availability?'<span class="badge available">Available</span>':'<span class="badge unavailable">Rented</span>'}</td><td><button class="small-btn" onclick="toggleVehicle(${v.id})">${v.availability?'Mark Rented':'Mark Available'}</button></td></tr>`).join("");document.getElementById("adminRentalsTable").innerHTML=d.rentals.length?d.rentals.slice(0,20).map(r=>`<tr><td>REN${r.rentalId}</td><td>${escapeHtml(r.customerName)}</td><td>${escapeHtml(r.vehicleModel)}</td><td>${escapeHtml(r.pickupDate)} → ${escapeHtml(r.returnDate)}</td><td>₹${Number(r.amount).toLocaleString("en-IN")}</td><td>${escapeHtml(r.status)}</td></tr>`).join(""):'<tr><td colspan="6">No rentals yet.</td></tr>';}catch(error){if(error.status===401||error.status===403)location.href="login.html";else alert(error.message);}}
async function addVehicle(){if(!(await guardAdminPage()))return;const model=document.getElementById("newModel").value.trim(),type=document.getElementById("newType").value,registration=document.getElementById("newRegistration").value.trim(),price=Number(document.getElementById("newPrice").value),image=document.getElementById("newImage")?.value.trim();if(!model||!registration||!price){alert("Please fill model, type, registration and price.");return;}const imageUrl=image||"https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1400&q=85";try{await api("/admin/vehicles",{method:"POST",body:JSON.stringify({model,type,registration,price,imageUrl,color:"Premium finish",gallery:[[imageUrl,"Exterior"]]})});["newModel","newRegistration","newPrice","newImage"].forEach(id=>{const el=document.getElementById(id);if(el)el.value="";});await renderAdmin();}catch(error){alert(error.message);}}
async function toggleVehicle(id){if(!(await guardAdminPage()))return;try{const d=await api("/admin/dashboard"),v=d.vehicles.find(x=>x.id===id);if(!v)return;await api(`/admin/vehicles/${id}/availability?available=${!v.availability}`,{method:"PATCH"});await renderAdmin();}catch(error){alert(error.message);}}
function showMessage(id,text,error=false){const el=document.getElementById(id);if(!el)return;el.textContent=text;el.style.color=error?"var(--danger)":"var(--success)";}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[ch]));}
