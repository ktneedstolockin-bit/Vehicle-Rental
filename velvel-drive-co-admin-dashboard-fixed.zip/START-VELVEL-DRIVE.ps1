$bat = Join-Path $PSScriptRoot "START-VELVEL-DRIVE.bat"
if (-not (Test-Path $bat)) {
    Write-Host "START-VELVEL-DRIVE.bat not found." -ForegroundColor Red
    exit 1
}
cmd.exe /c "`"$bat`""
