@echo off
setlocal
cd /d "%~dp0"
echo.
echo ================================================
echo   Velvel Drive Co. - Starting Spring Boot
echo ================================================
echo.

set "DB_URL=jdbc:mysql://localhost:3306/velvel_drive?useSSL=false^&serverTimezone=UTC^&allowPublicKeyRetrieval=true"
set "DB_USERNAME=root"

set /p "DB_PASSWORD=Enter MySQL root password: "
echo.

call mvn spring-boot:run

if errorlevel 1 (
  echo.
  echo ================================================
  echo Spring Boot failed to start.
  echo Read the first ERROR line above.
  echo ================================================
)
pause
endlocal
