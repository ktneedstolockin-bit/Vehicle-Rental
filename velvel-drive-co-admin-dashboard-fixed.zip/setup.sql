CREATE DATABASE IF NOT EXISTS velvel_drive CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE velvel_drive;
