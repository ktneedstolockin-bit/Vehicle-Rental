@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Velvel Drive Co. - Spring Boot

echo ============================================================
echo              VELVEL DRIVE CO. - BACKEND
echo ============================================================
echo.

where mvn >nul 2>&1
if errorlevel 1 (
  echo ERROR: Maven was not found in PATH.
  pause
  exit /b 1
)

echo Maven detected:
call mvn -version
if errorlevel 1 (
  echo ERROR: Maven could not be started.
  pause
  exit /b 1
)

echo.
echo MySQL must be running on localhost:3306.
echo Database: velvel_drive
echo Username: root
echo.
set "DB_URL=jdbc:mysql://localhost:3306/velvel_drive?createDatabaseIfNotExist=true^&useSSL=false^&serverTimezone=UTC^&allowPublicKeyRetrieval=true"
set "DB_USERNAME=root"
set /p "DB_PASSWORD=Enter your MySQL root password: "
echo.

echo Starting Velvel Drive Co...
echo Keep this window open while using http://localhost:8080/
echo.
call mvn spring-boot:run

echo.
echo ============================================================
echo Spring Boot stopped. Exit code: %ERRORLEVEL%
echo ============================================================
pause
endlocal
